<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->get('/', function () use ($router) {
    return $router->app->version();
});

// Auth routes
$router->group(['prefix' => 'auth'], function () use ($router) {
    $router->post('register', 'AuthController@register');
    $router->post('login', 'AuthController@login');
    $router->post('logout', ['middleware' => 'auth', 'uses' => 'AuthController@logout']);
    $router->get('me', ['middleware' => 'auth', 'uses' => 'AuthController@me']);
});

// Protected routes
$router->group(['middleware' => 'auth'], function () use ($router) {
    
    // Mahasiswa routes
    $router->post('/mahasiswa/create', 'MahasiswaController@create');
    $router->get('/mahasiswa/read', 'MahasiswaController@read');
    $router->put('/mahasiswa/update/{id}', 'MahasiswaController@update');
    $router->delete('/mahasiswa/delete/{id}', 'MahasiswaController@delete');
    
    // Dosen routes
    $router->post('/dosen/create', 'DosenController@create');
    $router->get('/dosen/read', 'DosenController@read');
    $router->put('/dosen/update/{id}', 'DosenController@update');
    $router->delete('/dosen/delete/{id}', 'DosenController@delete');
    
    // Makul routes
    $router->post('/makul/create', 'MakulController@create');
    $router->get('/makul/read', 'MakulController@read');
    $router->put('/makul/update/{id}', 'MakulController@update');
    $router->delete('/makul/delete/{id}', 'MakulController@delete');
});