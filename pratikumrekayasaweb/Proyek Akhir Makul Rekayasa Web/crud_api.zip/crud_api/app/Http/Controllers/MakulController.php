<?php

namespace App\Http\Controllers;

use App\Models\Makul;
use Illuminate\Http\Request;

class MakulController extends Controller
{
    public function create(Request $request)
    {
        $this->validate($request, [
            'kode_makul' => 'required|string|unique:makul,kode_makul',
            'nama_makul' => 'required|string|max:255',
            'sks' => 'required|integer|min:1|max:6',
            'semester' => 'required|integer|min:1|max:8',
            'dosen_id' => 'nullable|exists:dosen,id'
        ]);

        $makul = Makul::create($request->all());
        $makul->load('dosen');

        return response()->json([
            'status' => 'success',
            'message' => 'Mata kuliah created successfully',
            'data' => $makul
        ], 201);
    }

    public function read(Request $request)
    {
        $perPage = $request->get('per_page', 10);
        $makul = Makul::with('dosen')->orderBy('created_at', 'desc')->paginate($perPage);

        return response()->json([
            'status' => 'success',
            'data' => $makul
        ]);
    }

    public function update(Request $request, $id)
    {
        $makul = Makul::find($id);

        if (!$makul) {
            return response()->json([
                'status' => 'error',
                'message' => 'Mata kuliah not found'
            ], 404);
        }

        $this->validate($request, [
            'kode_makul' => 'string|unique:makul,kode_makul,' . $id,
            'nama_makul' => 'string|max:255',
            'sks' => 'integer|min:1|max:6',
            'semester' => 'integer|min:1|max:8',
            'dosen_id' => 'nullable|exists:dosen,id'
        ]);

        $makul->update($request->all());
        $makul->load('dosen');

        return response()->json([
            'status' => 'success',
            'message' => 'Mata kuliah updated successfully',
            'data' => $makul
        ]);
    }

    public function delete($id)
    {
        $makul = Makul::find($id);

        if (!$makul) {
            return response()->json([
                'status' => 'error',
                'message' => 'Mata kuliah not found'
            ], 404);
        }

        $makul->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Mata kuliah deleted successfully'
        ]);
    }
}