<?php

namespace App\Http\Controllers;

use App\Models\Dosen;
use Illuminate\Http\Request;

class DosenController extends Controller
{
    public function create(Request $request)
    {
        $this->validate($request, [
            'nip' => 'required|string|unique:dosen,nip',
            'nama' => 'required|string|max:255',
            'email' => 'required|email|unique:dosen,email',
            'fakultas' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255'
        ]);

        $dosen = Dosen::create($request->all());

        return response()->json([
            'status' => 'success',
            'message' => 'Dosen created successfully',
            'data' => $dosen
        ], 201);
    }

    public function read(Request $request)
    {
        $perPage = $request->get('per_page', 10);
        $dosen = Dosen::orderBy('created_at', 'desc')->paginate($perPage);

        return response()->json([
            'status' => 'success',
            'data' => $dosen
        ]);
    }

    public function update(Request $request, $id)
    {
        $dosen = Dosen::find($id);

        if (!$dosen) {
            return response()->json([
                'status' => 'error',
                'message' => 'Dosen not found'
            ], 404);
        }

        $this->validate($request, [
            'nip' => 'string|unique:dosen,nip,' . $id,
            'nama' => 'string|max:255',
            'email' => 'email|unique:dosen,email,' . $id,
            'fakultas' => 'string|max:255',
            'jabatan' => 'string|max:255'
        ]);

        $dosen->update($request->all());

        return response()->json([
            'status' => 'success',
            'message' => 'Dosen updated successfully',
            'data' => $dosen
        ]);
    }

    public function delete($id)
    {
        $dosen = Dosen::find($id);

        if (!$dosen) {
            return response()->json([
                'status' => 'error',
                'message' => 'Dosen not found'
            ], 404);
        }

        $dosen->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Dosen deleted successfully'
        ]);
    }
}