<?php

namespace App\Http\Controllers;

use App\Models\Mahasiswa;
use Illuminate\Http\Request;

class MahasiswaController extends Controller
{
    public function create(Request $request)
    {
        $this->validate($request, [
            'nim' => 'required|string|unique:mahasiswa,nim',
            'nama' => 'required|string|max:255',
            'email' => 'required|email|unique:mahasiswa,email',
            'jurusan' => 'required|string|max:255',
            'angkatan' => 'required|integer|min:2000|max:' . (date('Y') + 1)
        ]);

        $mahasiswa = Mahasiswa::create($request->all());

        return response()->json([
            'status' => 'success',
            'message' => 'Mahasiswa created successfully',
            'data' => $mahasiswa
        ], 201);
    }

    public function read(Request $request)
    {
        $perPage = $request->get('per_page', 10);
        $mahasiswa = Mahasiswa::orderBy('created_at', 'desc')->paginate($perPage);

        return response()->json([
            'status' => 'success',
            'data' => $mahasiswa
        ]);
    }

    public function update(Request $request, $id)
    {
        $mahasiswa = Mahasiswa::find($id);

        if (!$mahasiswa) {
            return response()->json([
                'status' => 'error',
                'message' => 'Mahasiswa not found'
            ], 404);
        }

        $this->validate($request, [
            'nim' => 'string|unique:mahasiswa,nim,' . $id,
            'nama' => 'string|max:255',
            'email' => 'email|unique:mahasiswa,email,' . $id,
            'jurusan' => 'string|max:255',
            'angkatan' => 'integer|min:2000|max:' . (date('Y') + 1)
        ]);

        $mahasiswa->update($request->all());

        return response()->json([
            'status' => 'success',
            'message' => 'Mahasiswa updated successfully',
            'data' => $mahasiswa
        ]);
    }

    public function delete($id)
    {
        $mahasiswa = Mahasiswa::find($id);

        if (!$mahasiswa) {
            return response()->json([
                'status' => 'error',
                'message' => 'Mahasiswa not found'
            ], 404);
        }

        $mahasiswa->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Mahasiswa deleted successfully'
        ]);
    }
}